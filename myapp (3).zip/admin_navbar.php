    <!--Warren Peterson-03/13/2020-->
    <!--GCU__CST_126__Blog Project-->
    <!--This is my own work-->
    
    <!--Admin Navbar Element-->
<div class="header">
	<div class="logo">
		<a href="<?php echo BASE_URL .'dashboard.php' ?>">
			<h1>Warren Blog - Admin</h1>
		</a>
	</div>
	<div class="user-info">
		<span>Warren</span> &nbsp; &nbsp; <a href="<?php echo BASE_URL . 'logout.php'; ?>" class="logout-btn">logout</a>
	</div>
</div>